export type Direction = "N"|"E"|"S"|"W";
export type ErrorKind = "syntax"|"runtime"|"logic";
export interface Position { x:number; y:number }
export interface Mission { title:string; text:string; start:[number,number,Direction]; base:[number,number]; walls:[number,number][]; resources:[number,number][]; goal:"base"|"allResources"|"allResourcesBase"; }
export interface RobotState { mission:number; x:number; y:number; dir:Direction; collected:number; actions:number; }
export interface UserState { displayName:string; completedModules:number[]; completedTasks:number[]; xp:number; }
export interface UIState { activeTab:string; lessonOpen:boolean; theme:string; }
export interface AppState { user:UserState; robot:RobotState; ui:UIState; settings:Record<string,unknown>; }
export interface Token { value:string; line:number; column:number; }
export type AstNode =
 | {type:"act"; action:"move"|"left"|"right"|"collect"; token:Token}
 | {type:"for"; count:number; body:AstNode[]; token:Token}
 | {type:"if"; condition:"isPathClear"|"isOnResource"; yes:AstNode[]; no:AstNode[]; token:Token};
