import type {AppState} from "./types";
import {StorageService} from "../storage/StorageService";
export class Store {
 private state:AppState; private listeners=new Set<(s:Readonly<AppState>)=>void>();
 constructor(private storage:StorageService<AppState>){this.state=storage.load()}
 get():Readonly<AppState>{return this.state}
 update(mutator:(draft:AppState)=>void){const next=structuredClone(this.state);mutator(next);this.state=next;this.storage.save(next);this.listeners.forEach(x=>x(this.state))}
 subscribe(fn:(s:Readonly<AppState>)=>void){this.listeners.add(fn);return()=>this.listeners.delete(fn)}
}
