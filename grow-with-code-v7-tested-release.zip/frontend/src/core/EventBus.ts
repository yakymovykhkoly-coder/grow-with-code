export type Events = {
 "mission:loaded": {index:number};
 "execution:started": void;
 "execution:failed": {message:string};
 "mission:completed": {index:number;actions:number;seconds:number};
};
export class EventBus {
 private listeners = new Map<keyof Events, Set<(payload:any)=>void>>();
 on<K extends keyof Events>(event:K, fn:(payload:Events[K])=>void){if(!this.listeners.has(event))this.listeners.set(event,new Set());this.listeners.get(event)!.add(fn as any);return()=>this.listeners.get(event)?.delete(fn as any)}
 emit<K extends keyof Events>(event:K,payload:Events[K]){this.listeners.get(event)?.forEach(fn=>fn(payload))}
}
