export class StorageService<T> {
 constructor(private key:string, private defaults:T){}
 load():T{try{const raw=localStorage.getItem(this.key);return raw?{...this.defaults,...JSON.parse(raw)}:structuredClone(this.defaults)}catch{return structuredClone(this.defaults)}}
 save(value:T):void{localStorage.setItem(this.key,JSON.stringify(value))}
 clear():void{localStorage.removeItem(this.key)}
}
