import type {AstNode,Token} from "../core/types";
import {tokenize} from "./Tokenizer"; import {RobotError} from "./RobotErrors";
export class Parser {
 private t:Token[]=[]; private p=0;
 parse(src:string):AstNode[]{this.t=tokenize(src);this.p=0;const out:AstNode[]=[];while(this.peek())out.push(this.statement());return out}
 private peek(){return this.t[this.p]}
 private take(value?:string){const t=this.t[this.p];if(!t)throw new RobotError("syntax",`Очікувалось '${value??"токен"}', але код закінчився`,this.t[this.p-1]);if(value&&t.value!==value)throw new RobotError("syntax",`Очікувалось '${value}', отримано '${t.value}'`,t);this.p++;return t}
 private block(){this.take("{");const a:AstNode[]=[];while(this.peek()?.value!=="}"){if(!this.peek())throw new RobotError("syntax","Не закрита фігурна дужка",this.t[this.p-1]);a.push(this.statement())}this.take("}");return a}
 private condition():"isPathClear"|"isOnResource"{this.take("robot");this.take(".");const n=this.take();this.take("(");this.take(")");if(n.value==="isPathClear"||n.value==="isOnResource")return n.value;throw new RobotError("syntax",`Невідома умова robot.${n.value}()`,n)}
 private statement():AstNode{const start=this.peek();if(!start)throw new RobotError("syntax","Неочікуваний кінець коду");
  if(start.value==="robot"){this.take("robot");this.take(".");const n=this.take();this.take("(");this.take(")");this.take(";");const map:any={move:"move",turnLeft:"left",turnRight:"right",collect:"collect"};if(!map[n.value])throw new RobotError("syntax",`Невідомий метод robot.${n.value}()`,n);return{type:"act",action:map[n.value],token:start}}
  if(start.value==="for"){this.take("for");this.take("(");this.take("int");const v=this.take().value;this.take("=");const s=Number(this.take().value);this.take(";");this.take(v);this.take("<");const e=Number(this.take().value);this.take(";");this.take(v);this.take("++");this.take(")");return{type:"for",count:Math.max(0,e-s),body:this.block(),token:start}}
  if(start.value==="if"){this.take("if");this.take("(");const condition=this.condition();this.take(")");const yes=this.block();let no:AstNode[]=[];if(this.peek()?.value==="else"){this.take("else");no=this.block()}return{type:"if",condition,yes,no,token:start}}
  throw new RobotError("syntax",`Не розумію конструкцію '${start.value}'`,start)
 }}
