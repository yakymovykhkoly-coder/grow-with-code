import type {ErrorKind,Token} from "../core/types";
export class RobotError extends Error {
 constructor(public kind:ErrorKind,message:string,public token?:Token){super(message);this.name=kind==="syntax"?"RobotSyntaxError":kind==="runtime"?"RobotRuntimeError":"RobotLogicError"}
 format(){return `${this.name}${this.token?` · рядок ${this.token.line}, колонка ${this.token.column}`:""}: ${this.message}`}
}
