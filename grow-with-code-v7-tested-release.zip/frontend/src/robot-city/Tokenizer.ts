import type {Token} from "../core/types";
import {RobotError} from "./RobotErrors";
export function tokenize(src:string):Token[]{
 const out:Token[]=[]; let i=0,line=1,column=1;
 const push=(value:string,l=line,c=column)=>out.push({value,line:l,column:c});
 const adv=(ch:string)=>{if(ch==="\n"){line++;column=1}else column++;i++};
 while(i<src.length){
  const ch=src[i];
  if(/\s/.test(ch)){adv(ch);continue}
  if(src.slice(i,i+2)==="//"){while(i<src.length&&src[i]!=="\n")adv(src[i]);continue}
  const l=line,c=column;
  if(src.slice(i,i+2)==="++"){push("++",l,c);adv("+");adv("+");continue}
  if("{}();.<>=+-".includes(ch)){push(ch,l,c);adv(ch);continue}
  const id=src.slice(i).match(/^[A-Za-z_][A-Za-z0-9_]*/)?.[0] ?? src.slice(i).match(/^\d+/)?.[0];
  if(id){push(id,l,c);for(const x of id)adv(x);continue}
  throw new RobotError("syntax",`Невідомий символ '${ch}'`,{value:ch,line,column});
 }
 return out;
}
