import type {Mission,Direction} from "../core/types";import {Parser} from "./Parser";import {Compiler,type Instruction} from "./Compiler";import {RobotError} from "./RobotErrors";
export class RobotVM{
 x=0;y=0;dir:Direction="E";actions=0;collected=0;resources:[number,number][]=[];private queue:Instruction[]=[];
 constructor(public mission:Mission,private parser=new Parser(),private compiler=new Compiler()){this.reset()}
 reset(){[this.x,this.y,this.dir]=this.mission.start;this.actions=0;this.collected=0;this.resources=this.mission.resources.map(r=>[...r]);this.queue=[]}
 compile(src:string){this.queue=this.compiler.compile(this.parser.parse(src));return this.queue}
 isPathClear(){const d:any={N:[0,-1],E:[1,0],S:[0,1],W:[-1,0]},[dx,dy]=d[this.dir],nx=this.x+dx,ny=this.y+dy;return nx>=0&&nx<5&&ny>=0&&ny<5&&!this.mission.walls.some(([x,y])=>x===nx&&y===ny)}
 isOnResource(){return this.resources.some(([x,y])=>x===this.x&&y===this.y)}
 private act(op:"move"|"left"|"right"|"collect"){if(++this.actions>120)throw new RobotError("runtime","Перевищено 120 дій");const dirs:Direction[]=["N","E","S","W"];if(op==="move"){if(!this.isPathClear())throw new RobotError("runtime","robot.move(): попереду перешкода або край поля");const d:any={N:[0,-1],E:[1,0],S:[0,1],W:[-1,0]},[dx,dy]=d[this.dir];this.x+=dx;this.y+=dy}else if(op==="left")this.dir=dirs[(dirs.indexOf(this.dir)+3)%4];else if(op==="right")this.dir=dirs[(dirs.indexOf(this.dir)+1)%4];else{const i=this.resources.findIndex(([x,y])=>x===this.x&&y===this.y);if(i<0)throw new RobotError("runtime","robot.collect(): тут немає деталі");this.resources.splice(i,1);this.collected++}}
 run(src:string){this.reset();const q=[...this.compile(src)];while(q.length){const i=q.shift()!;if(i.op==="branch"){const ok=i.condition==="isPathClear"?this.isPathClear():this.isOnResource();q.unshift(...this.compiler.compile(ok?i.yes:i.no,[]));continue}this.act(i.op)}if(!this.goalReached())throw new RobotError("logic","Код виконався, але мета місії не досягнута");return{actions:this.actions,x:this.x,y:this.y,collected:this.collected}}
 goalReached(){const base=this.x===this.mission.base[0]&&this.y===this.mission.base[1],all=this.resources.length===0;return this.mission.goal==="base"?base:this.mission.goal==="allResources"?all:base&&all}
}
