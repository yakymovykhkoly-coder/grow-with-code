import type {AppState} from "../core/types";import {Store} from "../core/Store";
export class CourseService{constructor(private store:Store){} completeModule(id:number){this.store.update((s:AppState)=>{if(!s.user.completedModules.includes(id))s.user.completedModules.push(id)})}}
