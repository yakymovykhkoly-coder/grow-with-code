import {readFileSync,readdirSync,statSync} from "node:fs";import {join} from "node:path";
const skip=new Set(["node_modules","dist",".git"]);const files=[];
function walk(d){for(const n of readdirSync(d)){if(skip.has(n))continue;const p=join(d,n),s=statSync(p);s.isDirectory()?walk(p):files.push(p)}} walk(".");
const bad=[],patterns=[/BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY/,/JWT_SECRET_BASE64\s*=\s*[A-Za-z0-9+/]{40,}/];
for(const f of files){if(!/\.(js|mjs|ts|html|css|json|md|toml|example)$/.test(f))continue;const t=readFileSync(f,"utf8");for(const p of patterns)if(p.test(t))bad.push(f)}
if(bad.length)throw new Error("Potential committed secret(s): "+bad.join(", "));
console.log("Secret audit: OK ("+files.length+" files scanned)");
