import {readFileSync,existsSync} from "node:fs";
const html=readFileSync("index.html","utf8");
const refs=[...html.matchAll(/(?:src|href)="([^"]+)"/g)].map(x=>x[1]).filter(x=>!x.startsWith("http")&&!x.startsWith("#")&&!x.startsWith("data:"));
const missing=refs.filter(x=>!existsSync(x.replace(/^\.\//,"")));
if(missing.length) throw new Error("Missing frontend assets: "+missing.join(", "));
if(html.indexOf("config.js")<0||html.indexOf("script.js")<0||html.indexOf("config.js")>html.indexOf("script.js")) throw new Error("config.js must load before script.js");
console.log("Frontend smoke: OK ("+refs.length+" local references checked)");
