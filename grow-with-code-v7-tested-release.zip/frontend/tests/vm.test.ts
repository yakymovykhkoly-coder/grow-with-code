import {describe,it,expect} from "vitest";import {RobotVM} from "../src/robot-city/RobotVM";import type {Mission} from "../src/core/types";
const m:Mission={title:"T",text:"",start:[0,0,"E"],base:[2,0],walls:[],resources:[],goal:"base"};
describe("RobotVM",()=>{
it("moves",()=>expect(new RobotVM(m).run("robot.move();robot.move();").x).toBe(2));
it("turns",()=>{const v=new RobotVM({...m,base:[0,1]});expect(v.run("robot.turnRight();robot.move();").y).toBe(1)});
it("blocks wall",()=>expect(()=>new RobotVM({...m,walls:[[1,0]]}).run("robot.move();")).toThrow("перешкода"));
it("blocks edge",()=>expect(()=>new RobotVM({...m,start:[0,0,"W"]}).run("robot.move();")).toThrow("край"));
it("collects",()=>{const v=new RobotVM({...m,base:[1,0],resources:[[1,0]],goal:"allResourcesBase"});expect(v.run("robot.move();robot.collect();").collected).toBe(1)});
it("rejects empty collect",()=>expect(()=>new RobotVM(m).run("robot.collect();")).toThrow("немає деталі"));
it("if clear",()=>expect(new RobotVM(m).run("if(robot.isPathClear()){robot.move();robot.move();}").x).toBe(2));
it("logic error",()=>expect(()=>new RobotVM(m).run("robot.move();")).toThrow("мета"));
it("resets between runs",()=>{const v=new RobotVM(m);v.run("robot.move();robot.move();");expect(v.run("robot.move();robot.move();").actions).toBe(2)});
it("counts actions",()=>expect(new RobotVM(m).run("robot.move();robot.move();").actions).toBe(2));
});
