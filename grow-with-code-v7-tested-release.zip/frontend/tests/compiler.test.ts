import {describe,it,expect} from "vitest";import {Parser} from "../src/robot-city/Parser";import {Compiler} from "../src/robot-city/Compiler";
describe("Compiler",()=>{const p=new Parser(),c=new Compiler();
it("one action",()=>expect(c.compile(p.parse("robot.move();"))).toHaveLength(1));
it("expands for",()=>expect(c.compile(p.parse("for (int i=0;i<3;i++){robot.move();}"))).toHaveLength(3));
it("zero loop",()=>expect(c.compile(p.parse("for (int i=3;i<3;i++){robot.move();}"))).toHaveLength(0));
it("keeps branch",()=>expect(c.compile(p.parse("if(robot.isPathClear()){robot.move();}"))[0].op).toBe("branch"));
it("rejects >30",()=>expect(()=>c.compile(p.parse("for(int i=0;i<31;i++){robot.move();}"))).toThrow("30"));
});
